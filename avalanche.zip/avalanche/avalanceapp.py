
import numpy as np
from flask import Flask, request, jsonify, render_template
from joblib import load
app = Flask(__name__)

model = load('Avalanche.save')

@app.route('/')
def home():
    return render_template('Avalance_Frontend.html')
@app.route('/y_predict',methods=['POST'])
def y_predict():
    x_test = [[int(x) for x in request.form.values()]]
    a= request.form['Slope']
    
    b=request.form['density']
    if(b=='Low Density'):
        b1=1
    if(b=='Highly Dense'):
        b1=0
    if(b=='Medium Density'):
        b1=2
    c=request.form['snowdensity']
    d=request.form['air']
    e=request.form['wind']
    
    sc=load('avstandard.save')
    total = [[a,int(b1),c,d,e]]
    print(total)
    prediction = model.predict(sc.transform(total))
    print(prediction)
    output=prediction[0]
    if(output==1):
        return render_template('Avalance_Frontend.html', prediction_text="He/She will Survive")
    else:
        return render_template('Avalance_Frontend.html',prediction_text="He/She won't Survive")
if __name__ == "__main__":
    app.run(debug=True)
